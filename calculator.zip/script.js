// Variables for the calculation
let displayValue = '';
let firstOperand = null;
let operator = null;
let waitingForSecondOperand = false;

// Get display element
const display = document.getElementById('calc-display');

// Function to update the display
function updateDisplay() {
    display.value = displayValue || '0';
}

// Handle number input
function inputDigit(digit) {
    if (waitingForSecondOperand) {
        displayValue = digit;
        waitingForSecondOperand = false;
    } else {
        displayValue = displayValue === '' ? digit : displayValue + digit;
    }
    updateDisplay();
}

// Handle operator input
function handleOperator(nextOperator) {
    if (firstOperand === null) {
        firstOperand = parseFloat(displayValue);
    } else if (operator) {
        const result = performCalculation(operator, firstOperand, parseFloat(displayValue));
        displayValue = `${result}`;
        firstOperand = result;
    }
    operator = nextOperator;
    waitingForSecondOperand = true;
    updateDisplay();
}

// Perform the calculations
function performCalculation(operator, firstOperand, secondOperand) {
    switch (operator) {
        case '+':
            return firstOperand + secondOperand;
        case '-':
            return firstOperand - secondOperand;
        case '×':
            return firstOperand * secondOperand;
        case '÷':
            return firstOperand / secondOperand;
        default:
            return secondOperand;
    }
}

// Handle decimal input
function inputDecimal(dot) {
    if (!displayValue.includes(dot)) {
        displayValue += dot;
    }
    updateDisplay();
}

// Handle clear button
function clearCalculator() {
    displayValue = '';
    firstOperand = null;
    operator = null;
    waitingForSecondOperand = false;
    updateDisplay();
}

// Handle button clicks
const buttons = document.querySelectorAll('.button');
buttons.forEach(button => {
    button.addEventListener('click', () => {
        const { innerText: value } = button;

        if (!isNaN(value)) {
            inputDigit(value);
        } else if (value === 'C') {
            clearCalculator();
        } else if (value === '.') {
            inputDecimal(value);
        } else if (value === '=') {
            handleOperator(operator);
        } else {
            handleOperator(value);
        }
    });
});

// Initial display update
updateDisplay();
